package Controller;

import DTO.DTO;
import Viewer.TUIViewer;
import Viewer.Viewer;

public interface Controller {
	boolean execute(int num,DTO dto,Viewer viewer);
}
