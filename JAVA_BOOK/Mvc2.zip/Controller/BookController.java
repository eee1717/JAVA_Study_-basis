package Controller;

import DTO.BookDTO;
import DTO.DTO;
import Service.BookService;
import Viewer.GUIViewer;
import Viewer.TUIViewer;
import Viewer.Viewer;

public class BookController implements Controller{

	//멤버 
	BookService service=service =BookService.getInstance();
	

	@Override
	public boolean execute(int num,DTO dto,Viewer view) {
		
		BookDTO bdto = (BookDTO)dto;
	
		
		
		if(num==1) //등록
		{	
			return service.Insert(bdto);	//서비스 실행
		}
		else if(num==2) //조회
		{
			return service.Select(bdto,view);
		}
		else if(num==3)
		{
			
		}
		else if(num==4)
		{
			
		}
		else
		{
			
		}
		
		return false;
	 
		
	}
	


}
