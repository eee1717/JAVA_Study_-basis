package Controller;

import DTO.AuthDTO;
import DTO.BookDTO;
import DTO.DTO;
import Service.AuthService;
import Viewer.TUIViewer;
import Viewer.Viewer;

public class AuthController implements Controller{

	AuthService service = new AuthService();
	@Override
	public boolean execute(int num, DTO dto,Viewer view) {
		//1 : 회원 로그인  2 : 직원 로그인
		
		AuthDTO adto = (AuthDTO)dto;
		
		if(num==1)
		{
			return service.MemberLogin(adto);
		}
		else if(num==2)
		{
			return service.EmployeeLogin(adto);
		}
		return false;
	}

}
