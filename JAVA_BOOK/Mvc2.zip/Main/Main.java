package Main;


import java.util.Scanner;

import Viewer.GUIViewer;
import Viewer.TUIViewer;

public class Main {
	
	public static void main(String[] args) {
		
		//콘솔창 Viewer
		//Viewer viewer = Viewer.getInstance();
		//viewer.Login();
		
		//로그인창 Viewer
		GUIViewer viewer = new GUIViewer();
		
		
	 

	}

}
