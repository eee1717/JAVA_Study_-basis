package Domain;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import DTO.BookDTO;
import Viewer.Viewer;

public class BookDAO {
	
	private String driver = "oracle.jdbc.driver.OracleDriver";
	private String url = "jdbc:oracle:thin:@localhost:1521:XE";
	private String user = "book_ex";
	private String password = "book_ex";
	
	private String sql; 					//sql 문저장
	private PreparedStatement pstmt =null;	//sql문 명령 전달하는 용도
	private ResultSet rs = null;			//쿼리 결과 저장
	private Connection con = null;			//연결 정보 저장
	
	//싱글톤 패턴
	private static BookDAO instance = new BookDAO();
	 
	public static BookDAO getInstance(){
		if(instance==null)
			instance=new BookDAO();
		return instance;
	}
	private BookDAO(){
		try 
		{
			Class.forName(driver);
			System.out.println("Driver Loading Success");
			con=DriverManager.getConnection(url,user,password);
			System.out.println("DB Connected..");
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public boolean Insert(BookDTO dto){
		try {
			
			sql="insert into book_tbl values(?,?,?,?,?,?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, dto.getBookCode());
			pstmt.setInt(2, dto.getClassificationId());
			pstmt.setString(3, dto.getBookAuthor());
			pstmt.setString(4, dto.getBookName());
			pstmt.setString(5, dto.getBookName());
			if(dto.isIsreserve())
				pstmt.setString(6, "1");
			else
				pstmt.setString(6, "0");
			
			int result = pstmt.executeUpdate();
			if(result!=0) {
				return true;
			} 
			 
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try{pstmt.close();}catch(Exception e) {e.printStackTrace();}
		}
		
		return false;
		
	}
	
	public ResultSet Select(BookDTO dto)
	{
		String keyword = dto.getBookName();
		try {

			
			
			pstmt= con.prepareStatement("select * from book_tbl where book_Name like '%"+keyword+"%'");
			//pstmt.setString(1, keyword);
			rs = pstmt.executeQuery();
			
			
			return rs;
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			
		}
		return null;
		
	}
	
	
	
}
