package Domain;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import DTO.AuthDTO;

public class AuthDAO {
	private String driver = "oracle.jdbc.driver.OracleDriver";
	private String url = "jdbc:oracle:thin:@localhost:1521:XE";
	private String user = "book_ex";
	private String password = "book_ex";
	
	private String sql; 					//sql 문저장
	private PreparedStatement pstmt =null;	//sql문 명령 전달하는 용도
	private ResultSet rs = null;			//쿼리 결과 저장
	private Connection con = null;			//연결 정보 저장
	
	//싱글톤 패턴
	private static AuthDAO instance = new AuthDAO();
	 
	public static AuthDAO getInstance(){
		if(instance==null)
			instance=new AuthDAO();
		return instance;
	}
	private AuthDAO(){
		try 
		{
			Class.forName(driver);
			System.out.println("Driver Loading Success");
			con=DriverManager.getConnection(url,user,password);
			System.out.println("DB Connected..");
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//MemberLogin
	public boolean MemberLogin(AuthDTO dto) {
		try {
			pstmt = con.prepareStatement("select id,pw from mem_tbl where id=?");
			pstmt.setString(1, dto.getId());
			rs = pstmt.executeQuery();
			String tid=null,tpw=null;
			while(rs.next())
			{
				tid = rs.getString("id");
				tpw = rs.getString("pw");
			}
			
			if(tid!=null && tpw!=null)
			{
				if(tid.equals(dto.getId())&& tpw.equals(dto.getPw()))
				{
					return true;
				}
			}

		
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try{rs.close();}catch(Exception e) {}
			try{pstmt.close();}catch(Exception e) {}
			
		}
		
		
		return false;
	}
	
	//EmployeeLogin
	public boolean EmployeeLogin(AuthDTO dto) {
		try {
			
			pstmt = con.prepareStatement("select id,pw from emp_tbl where id=?");
			pstmt.setString(1, dto.getId());
			rs = pstmt.executeQuery();
			String tid=null,tpw=null;
			while(rs.next())
			{
				tid = rs.getString("id");
				tpw = rs.getString("pw");
			}
			System.out.println(dto.getId());
			
			if(tid!=null && tpw!=null)
			{
				if(tid.equals(dto.getId())&& tpw.equals(dto.getPw()))
				{
					return true;
				}
			}

		
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try{rs.close();}catch(Exception e) {}
			try{pstmt.close();}catch(Exception e) {}
			
		}
		
		return false;
	
	}
	
}
