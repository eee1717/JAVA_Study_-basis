package Viewer;

import java.sql.ResultSet;
import java.util.Scanner;

import Controller.FrontController;
import DTO.AuthDTO;
import DTO.BookDTO;

public class TUIViewer  extends Viewer {
	
	FrontController controller=FrontController.getInstance();
	Scanner sc = new Scanner(System.in);
	int num=0;
	
	//싱글톤 패턴
	private static TUIViewer instance = new TUIViewer();
	private TUIViewer(){
			
	}
	public static TUIViewer getInstance(){
		if(instance==null)
			instance=new TUIViewer();
		return instance;
	}
	
	
	//Login 메뉴
	public void Login() {
		while(true)
		{
		//계정입력시 DB로부터 가져와서 일반계정인지 관리자 계정인지 확인할 것
		//직원 로그인 / 회원 로그인
		System.out.println("------------- LOGIN -------------");
		System.out.println("1 회원 로그인");
		System.out.println("2 직원 로그인");
		System.out.println("3 종료");
		System.out.println("------------- LOGIN -------------");
		System.out.print("번호 : " );
		num=sc.nextInt();
			switch(num)
			{
			case 1:	//회원 로그인
				System.out.print("ID : " );
				String id = sc.next();
				System.out.print("PW : " );
				String pw = sc.next();
				AuthDTO dto = new AuthDTO(id,pw);
				boolean result = controller.SubControllerEX("AUTH", 1, dto,this);
//				if(result==true)
//					MemberMenu();
//				else
//					System.out.println("로그인 실패..");
				break;
				
			case 2:	//직원 로그인
				System.out.print("ID : " );
				String id2 = sc.next();
				System.out.print("PW : " );
				String pw2 = sc.next();
				AuthDTO dto2 = new AuthDTO(id2,pw2);
				boolean result2 = controller.SubControllerEX("AUTH", 2, dto2,this);
				if(result2==true) 
					EmployeeMenu();
				else
					System.out.println("로그인 실패..");
				
				break;
			case 3:
				System.out.println("프로그램을 종료합니다.");
				System.exit(-1);
				break;
			default:
				System.out.println("다시 입력..");
			}
		}
	}
	
	
	

	void EmployeeMenu() {		 
		while(true)
		{
		System.out.println("------------- 직 원 메 뉴 -------------");
		System.out.println("1 Insert");
		System.out.println("2 Update");
		System.out.println("3 Select");
		System.out.println("4 Prev");
		System.out.println("------------- 직 원 메 뉴 -------------");	
		System.out.print("번호 : " );
		num=sc.nextInt();
		switch(num)
		{
		case 1:
			System.out.print("코드|분류번호|저자|책제목|출판사 > ");
			int code=sc.nextInt();
			int classid=sc.nextInt();
			String author = sc.next();
			String title = sc.next();
			String publisher = sc.next();
			BookDTO dto = new BookDTO(code,classid,author,title,publisher,false);
			//controller로 전달
			boolean result = controller.SubControllerEX("BOOK",1,dto,this);
			
			break;
		case 2:
			 
			break;
		case 3:
			 
			break;
		case 4:
			return ;
		default:
			System.out.println("다시 입력..");
		
		}
		}
	}	

	
}
