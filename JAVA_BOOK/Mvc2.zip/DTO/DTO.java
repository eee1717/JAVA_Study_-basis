package DTO;

public class DTO {
	
}
