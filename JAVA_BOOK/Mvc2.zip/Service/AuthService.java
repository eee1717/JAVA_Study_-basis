package Service;

import DTO.AuthDTO;
import Domain.AuthDAO;
import Domain.BookDAO;

public class AuthService {

	AuthDAO dao;
	//싱글톤 패턴
	private static AuthService instance = new AuthService();
	public AuthService(){
		
		dao = AuthDAO.getInstance();
	}
	public static AuthService getInstance(){
		if(instance==null)
			instance=new AuthService();
		return instance;
	}
	
	//회원로그인
	public boolean MemberLogin(AuthDTO dto){
		return dao.MemberLogin(dto);
	}
	
	//직원로그인
	public boolean EmployeeLogin(AuthDTO dto) {
		return dao.EmployeeLogin(dto);
	}
	
}
