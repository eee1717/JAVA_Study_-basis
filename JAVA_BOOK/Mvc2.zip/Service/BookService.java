package Service;

import java.sql.ResultSet;
import java.sql.SQLException;

import DTO.BookDTO;
import Domain.BookDAO;
import Viewer.GUIViewer;
import Viewer.Viewer;

public class BookService {
	BookDAO bookdao;
	
	//싱글톤 패턴
	private static BookService instance = new BookService();
	private BookService(){
		bookdao=BookDAO.getInstance();
	}
	public static BookService getInstance(){
		if(instance==null)
			instance=new BookService();
		return instance;
	}

	
	public boolean Insert(BookDTO dto) {
		
		return bookdao.Insert(dto);
	}
	
	public boolean Select(BookDTO dto , Viewer view)
	{
		
		GUIViewer gui = (GUIViewer)view;
		
	 
		ResultSet rs =  bookdao.Select(dto);
		 
		gui.area.setText("");
		if(rs!=null)
		{
			 
		try {
		//area 에 내용 전달할 것
		while(rs.next())
		{
				
				gui.area.append(String.valueOf(rs.getInt("book_code"))+"\t");
				gui.area.append(String.valueOf(rs.getInt("classification_Id"))+"\t");
				gui.area.append(rs.getString("book_Author")+"\t");
				gui.area.append(rs.getString("book_Name")+"\t");
				gui.area.append(rs.getString("publisher")+"\t");
				if(rs.getBoolean("isreserve")) {
					gui.area.append("대여중\n");
				}else {
					gui.area.append("대여가능\n");
				}
				
			
		 
		}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
			return true;
		}
		return false;
		
	}
//	boolean Update(BookDTO dto) {
//		
//	}
//	boolean Select() {
//		
//	}
//	boolean Select(int num) {
//		
//	}
	
}
